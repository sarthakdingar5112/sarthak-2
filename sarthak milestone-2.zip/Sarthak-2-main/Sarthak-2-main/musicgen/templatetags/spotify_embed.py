import re
from urllib.parse import urlparse
from django import template

register = template.Library()

# --- Regex patterns to detect Spotify resource types ---
_SPOTIFY_PATTERNS = {
    "track": re.compile(r"/track/([A-Za-z0-9]+)"),
    "playlist": re.compile(r"/playlist/([A-Za-z0-9]+)"),
    "album": re.compile(r"/album/([A-Za-z0-9]+)"),
    "artist": re.compile(r"/artist/([A-Za-z0-9]+)"),
}


def _id_from_path(path):
    """
    Extract the Spotify ID and type (track/album/playlist/artist) from a URL path.
    """
    for kind, pat in _SPOTIFY_PATTERNS.items():
        match = pat.search(path)
        if match:
            return kind, match.group(1)
    return None, None


@register.filter
def spotify_embed(src_url: str, theme: str = "0"):
    """
    Convert a public Spotify URL to an embeddable iframe URL.
    
    Usage in Django templates:
        {% load spotify_embed %}
        <iframe src="{{ track.spotify_url|spotify_embed }}" ...></iframe>
    
    Args:
        src_url: The normal Spotify URL (track, playlist, album, or artist)
        theme: "0" = dark theme (default), "1" = light theme
    """
    if not src_url:
        return ""
    try:
        parsed = urlparse(src_url)
        kind, spotify_id = _id_from_path(parsed.path)
        if not kind or not spotify_id:
            return ""
        return f"https://open.spotify.com/embed/{kind}/{spotify_id}?utm_source=generator&theme={theme}"
    except Exception:
        return ""
