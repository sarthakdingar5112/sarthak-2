from django.urls import path
from . import views

app_name = 'musicgen'

urlpatterns = [
    # Home (requires login in the view)
    path('', views.home, name='home'),

    # Auth pages (your custom views)
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Text analyze flow
    path('analyze/', views.analyze_view, name='analyze'),
    path('prompt/<int:pk>/', views.prompt_detail, name='prompt_detail'),
    path('generate/', views.generate_view, name='generate'),
    path('gen/<int:pk>/', views.generation_detail, name='generation_detail'),

    # Serve generated audio from DB
    path('audio/<int:pk>/', views.audio_blob_view, name='audio_blob'),

    # Image analyze
    path('image-analyze/', views.image_analyze_view, name='image_analyze'),

    # JSON APIs
    path('api/register', views.api_register, name='api_register'),
    path('api/login', views.api_login, name='api_login'),
    path('api/history/<int:user_id>', views.api_history, name='api_history'),
]
